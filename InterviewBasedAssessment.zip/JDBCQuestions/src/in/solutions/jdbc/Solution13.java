package in.solutions.jdbc;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Solution13 {
    private static final String JDBC_URL = "jdbc:postgresql://localhost:5432/mydatabase";
    private static final String USERNAME = "your-username";
    private static final String PASSWORD = "your-password";

    public static void main(String[] args) {
        String inputFile = "input.txt";

        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
            // Enable batch updates
            connection.setAutoCommit(false);

            // Prepare the SQL statement for batch updates
            String insertQuery = "INSERT INTO mytable (name, age) VALUES (?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);

            // Read the input data from the file and add it to the batch
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                String name = data[0].trim();
                int age = Integer.parseInt(data[1].trim());

                preparedStatement.setString(1, name);
                preparedStatement.setInt(2, age);
                preparedStatement.addBatch();
            }
            reader.close();

            // Execute the batch update
            int[] batchResult = preparedStatement.executeBatch();

            // Commit the changes
            connection.commit();

            System.out.println("Batch update executed successfully. Rows affected: " + batchResult.length);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

