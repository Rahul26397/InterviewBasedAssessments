package in.solutions.java;
//Example using Abstract Class:

abstract class Animal {
    abstract void sound();
}

class Dog extends Animal {
    void sound() {
        System.out.println("Dog barks");
    }
}

class Cat extends Animal {
    void sound() {
        System.out.println("Cat meows");
    }
}

public class Solution5Abstract {
    public static void main(String[] args) {
        Animal dog = new Dog();
        dog.sound(); // Output: Dog barks

        Animal cat = new Cat();
        cat.sound(); // Output: Cat meows
    }
}



/*
Key Differences between Abstract Classes and Interfaces:

Definition: An abstract class is a class that cannot be instantiated and is typically used as a base for its subclasses. An interface is a reference type that defines a contract for classes to implement certain methods.

Instantiation: Abstract classes cannot be instantiated using the new keyword, while interfaces cannot be instantiated at all. However, concrete subclasses can be created for both abstract classes and interfaces.

Inheritance: A class can extend only one abstract class but can implement multiple interfaces. This allows for more flexibility in terms of reusing code through interfaces.

Method Implementation: An abstract class can have both abstract and non-abstract methods. It can provide default implementations for some methods and leave others abstract, which the subclasses must implement. On the other hand, all methods defined in an interface are implicitly abstract, and the implementing class must provide implementations for all interface methods.

Access Modifiers: In an abstract class, methods can have different access modifiers (public, protected, or default) based on the design requirements. In interfaces, all methods are implicitly public and cannot have any other access modifier.

Fields and Constants: An abstract class can have instance variables, fields, and non-constant static variables. It can also define constants. Interfaces
*/
