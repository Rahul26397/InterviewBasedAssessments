package in.solutions.java;
import java.util.Scanner;

public class Solution3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter an integer: ");
            int num = scanner.nextInt();

            if (num < 0) {
                throw new IllegalArgumentException("Negative numbers are not allowed");
            }

            System.out.println("Entered number: " + num);
        } catch (IllegalArgumentException e) {
            System.out.println("Exception caught: " + e.getMessage());
        }
    }
}
