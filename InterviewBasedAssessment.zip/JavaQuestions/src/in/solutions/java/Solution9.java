package in.solutions.java;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class Solution9 {
    private static final int QUEUE_CAPACITY = 10;
    private static final int NUM_ITEMS = 100;

    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();
        Object lock = new Object();

        Producer producer = new Producer(queue, lock);
        Consumer consumer = new Consumer(queue, lock);

        Thread producerThread = new Thread(producer);
        Thread consumerThread = new Thread(consumer);

        producerThread.start();
        consumerThread.start();

        try {
            producerThread.join();
            consumerThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        int sum = consumer.getSum();
        System.out.println("Sum of numbers: " + sum);
    }

    static class Producer implements Runnable {
        private final Queue<Integer> queue;
        private final Object lock;
        private final Random random;

        public Producer(Queue<Integer> queue, Object lock) {
            this.queue = queue;
            this.lock = lock;
            this.random = new Random();
        }

        @Override
        public void run() {
            for (int i = 0; i < NUM_ITEMS; i++) {
                try {
                    Thread.sleep(random.nextInt(500)); // Simulate some work being done
                    synchronized (lock) {
                        while (queue.size() == QUEUE_CAPACITY) {
                            lock.wait(); // Wait until the queue has space
                        }
                        int number = random.nextInt(100);
                        queue.add(number);
                        System.out.println("Produced: " + number);
                        lock.notifyAll(); // Notify consumer that there is an item in the queue
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    static class Consumer implements Runnable {
        private final Queue<Integer> queue;
        private final Object lock;
        private int sum;

        public Consumer(Queue<Integer> queue, Object lock) {
            this.queue = queue;
            this.lock = lock;
            this.sum = 0;
        }

        @Override
        public void run() {
            while (true) {
                try {
                    Thread.sleep(500); // Simulate some work being done
                    synchronized (lock) {
                        while (queue.isEmpty()) {
                            lock.wait(); // Wait until the queue has items
                        }
                        int number = queue.poll();
                        sum += number;
                        System.out.println("Consumed: " + number);
                        lock.notifyAll(); // Notify producer that there is space in the queue
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (queue.isEmpty() && Thread.currentThread().isInterrupted()) {
                    break;
                }
            }
        }

        public int getSum() {
            return sum;
        }
    }
}  
