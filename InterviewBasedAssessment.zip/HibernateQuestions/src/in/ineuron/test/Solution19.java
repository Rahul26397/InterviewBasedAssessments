package in.ineuron.test;

import java.util.List;


import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import in.ineuron.model.Student;
import in.ineuron.util.HibernateUtil;

public class Solution19 {

	public static void main(String[] args) {

		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		Integer id = null;
		try {
			session = HibernateUtil.getSession();

			if (session != null)
				transaction = session.beginTransaction();

			if (transaction != null) {

				 // Create a new Employee object
		        Student student = new Student();
		        student.setSname("Rahul");
		        student.setSaddress("india");
		        student.setSage(26);
		      
		        session.save(student);
		        
		        // Retrieve the inserted data from the database
		        Student insertedStudent = (Student) session.get(Student.class, student.getSid());

		        // Display the retrieved data on the console
		        System.out.println("ID: " + insertedStudent.getSid());
	            System.out.println("Name: " + insertedStudent.getSname());
	            System.out.println("Address: " + insertedStudent.getSaddress());
	            System.out.println("Age: " + insertedStudent.getSage());
	            System.out.println();
			}

		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (flag) {
				transaction.commit();
				System.out.println("Object saved to database....");
				System.out.println("object saved with the id :: " + id);
			} else {
				transaction.rollback();
				System.out.println("Object not saved to database...");
			}

			HibernateUtil.closeSession(session);
			HibernateUtil.closeSessionFactory();
		}

	}

}
