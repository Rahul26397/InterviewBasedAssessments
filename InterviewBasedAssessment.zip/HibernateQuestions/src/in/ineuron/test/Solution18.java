package in.ineuron.test;

import java.util.List;


import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import in.ineuron.model.Student;
import in.ineuron.util.HibernateUtil;

public class Solution18 {

	public static void main(String[] args) {

		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		Integer id = null;
		try {
			session = HibernateUtil.getSession();

			if (session != null)
				transaction = session.beginTransaction();

			if (transaction != null) {

				// Retrieve data from the table using Hibernate
		        List<Student> students = session.createQuery("FROM Student", Student.class).getResultList();
                
		        // Display the retrieved data on the console
		        for (Student student : students) {
		            System.out.println("ID: " + student.getSid());
		            System.out.println("Name: " + student.getSname());
		            System.out.println("Address: " + student.getSaddress());
		            System.out.println("Age: " + student.getSage());
		            System.out.println();
		        }
				flag = true;
			}

		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (flag) {
				transaction.commit();
				System.out.println("Object saved to database....");
				System.out.println("object saved with the id :: " + id);
			} else {
				transaction.rollback();
				System.out.println("Object not saved to database...");
			}

			HibernateUtil.closeSession(session);
			HibernateUtil.closeSessionFactory();
		}

	}

}
